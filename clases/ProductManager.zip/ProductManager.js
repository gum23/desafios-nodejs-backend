
class ProductManager {

  constructor(){
    this.products = [];
    this.id = 0;
  }

  addProduct(title, description, price, thumbnail, code, stock){

    if (!title || !description || !price || !thumbnail || !code || !stock) {
      console.log("Todos los campos son obligatorios");
      return
    }
    
    if (!this.products.some((p) => p.code === code)) {
      
      let newProduct = {id: this.id++, title, description, price, thumbnail, code, stock}

      this.products.push(newProduct);
      console.log(`El producto ${title} se agregó correctamente`);
    } else {
      console.log(`Ya existe un producto con el código: ${code}`);
      return
    }

  }

  getProducts(){
    return this.products;
  }

  getProductsById(id){
    let product = this.products.find(product => product.id === id);

    if (product == undefined) {
      return "Not Found!";
    } else {
      return product;
    }
  }

}

const producto = new ProductManager();

console.log(producto.getProducts());
console.log("----------------------------------------------------");
producto.addProduct("producto prueba", "este es un producto prueba", 200, "sin imagen","abc123", 25);
console.log("----------------------------------------------------");
console.log(producto.getProducts());
producto.addProduct("producto prueba", "este es un producto prueba", 200, "sin imagen","abc123", 25);
console.log("----------------------------------------------------");
console.log(producto.getProductsById(0));
console.log("----------------------------------------------------");
console.log(producto.getProductsById(2));